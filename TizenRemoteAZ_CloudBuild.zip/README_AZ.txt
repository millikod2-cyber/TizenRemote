TIZEN REMOTE AZ — Android layihə mənbə kodu
Hədəf TV: Samsung UE43TU7100UXRU (Tizen)
TV IP: 192.168.100.56 (sonradan dəyişə bilər)

DAXİLDİR
- Azərbaycan dilində sadə, tünd interfeys
- Wi-Fi / Tizen Remote Control WebSocket bağlantısı (WSS, port 8002)
- İstiqamət, OK, Geri, Ev, Menyu, səs, kanal, mənbə və media düymələri
- Reklam və qeydiyyat yoxdur

MƏHDUDİYYƏTLƏR
- Bu, mənbə kodu layihəsidir; bu mühitdə Android SDK/Gradle olmadığı üçün APK kompilyasiya edilməyib.
- Bluetooth pult bağlantısı daxil deyil. Samsung Tizen TV-lərdə standart telefon-pult əmrləri adətən şəbəkə üzərindən göndərilir; Bluetooth HID dəstəyi model/TV proqram təminatından asılıdır və bu tətbiqdə təsdiqlənməyib.
- TV ilk qoşulmada ekranda icazə istəyə bilər.
- Bəzi TV firmware versiyalarında WebSocket sertifikatı və protokol davranışı fərqlənə bilər.

APK-NI NECƏ YIĞMAQ
1. AndroidIDE kimi Android Gradle layihəsini aça bilən IDE-də bu qovluğu aç.
2. İnternetə qoşul; Gradle və OkHttp asılılığı yüklənməlidir.
3. Gradle sync et.
4. :app:assembleDebug tapşırığını işə sal.
5. APK: app/build/outputs/apk/debug/app-debug.apk

TELEFONDA SINAQ
- Telefon və TV eyni Wi-Fi şəbəkəsində olsun.
- IP sahəsində TV-nin hazırkı IP-sini saxla/yaz.
- Qoşul düyməsinə bas və TV-də icazəni təsdiqlə.


AVTOMATİK BULUD KOMPİLYASİYASI (TELEFONDAN)
Layihədə .github/workflows/build-apk.yml var. GitHub-a layihə kimi yüklədikdən sonra:
1. Repository > Actions bölməsinə gir.
2. "Build Tizen Remote AZ APK" workflow seç.
3. Run workflow bas.
4. Build bitəndə TizenRemoteAZ-debug-apk artifact-ni yüklə və içindən app-debug.apk faylını götür.
Bu üsul üçün GitHub hesabı və internet lazımdır; GitHub hesabının parolunu heç kimə göndərmə.
