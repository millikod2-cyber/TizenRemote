package az.tizenremote;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import okhttp3.*;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.*;

public class MainActivity extends Activity {
    private EditText ip;
    private TextView status, connectButton;
    private WebSocket ws;
    private OkHttpClient client;
    private boolean connected = false;
    private float downX, downY;
    private long downAt;
    private final int BG=0xFF080B13, PANEL=0xFF171D2B, BTN=0xFF252E43, PURPLE=0xFF8065FF, WHITE=0xFFF4F5FA, MUTED=0xFF9AA4B8;
    private final String tvDefault="192.168.100.56";

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); client=makeClient(); render(); }

    private OkHttpClient makeClient(){
        try {
            TrustManager[] t={new X509TrustManager(){
                public java.security.cert.X509Certificate[] getAcceptedIssuers(){return new java.security.cert.X509Certificate[0];}
                public void checkClientTrusted(java.security.cert.X509Certificate[] c,String a){}
                public void checkServerTrusted(java.security.cert.X509Certificate[] c,String a){}
            }};
            SSLContext s=SSLContext.getInstance("TLS"); s.init(null,t,new java.security.SecureRandom());
            return new OkHttpClient.Builder().sslSocketFactory(s.getSocketFactory(),(X509TrustManager)t[0])
              .hostnameVerifier((h,ss)->true).connectTimeout(8,TimeUnit.SECONDS).readTimeout(0,TimeUnit.MILLISECONDS).build();
        } catch(Exception e){ return new OkHttpClient(); }
    }
    private GradientDrawable shape(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(null,Typeface.BOLD); return t; }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER); return l; }
    private void render(){
        LinearLayout root=column(); root.setPadding(dp(20),dp(18),dp(20),dp(20)); root.setBackgroundColor(BG);
        TextView brand=text("TIZEN REMOTE AZ",22,WHITE,true); root.addView(brand);
        TextView sub=text("SAMSUNG SMART TV  •  REKLAMSIZ",11,MUTED,true); sub.setPadding(0,dp(5),0,dp(18)); root.addView(sub);
        LinearLayout card=column(); card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackground(shape(PANEL,18));
        card.addView(text("TELEVİZORUN IP ÜNVANI",10,MUTED,true));
        ip=new EditText(this); ip.setSingleLine(true); ip.setText(tvDefault); ip.setTextColor(WHITE); ip.setHintTextColor(MUTED); ip.setTextSize(16); ip.setSelectAllOnFocus(true); ip.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI); ip.setBackgroundColor(Color.TRANSPARENT); card.addView(ip);
        Button connect=button("TELEVİZORA QOŞUL",true); card.addView(connect); connect.setOnClickListener(v->connect());
        status=text("●  Qoşulmayıb",13,0xFFFFC857,false); status.setPadding(0,dp(12),0,dp(8)); card.addView(status); root.addView(card);
        TextView remoteTitle=text("PULT",13,WHITE,true); remoteTitle.setPadding(dp(2),dp(22),0,dp(10)); root.addView(remoteTitle);
        LinearLayout pad=column(); pad.setGravity(Gravity.CENTER); pad.setPadding(dp(10),dp(12),dp(10),dp(12)); pad.setBackground(shape(PANEL,22));
        addKeyRow(pad,null,new String[]{"KEY_UP"},new String[]{"▲"});
        addKeyRow(pad,null,new String[]{"KEY_LEFT","KEY_ENTER","KEY_RIGHT"},new String[]{"◀","OK","▶"});
        addKeyRow(pad,null,new String[]{"KEY_DOWN"},new String[]{"▼"});
        root.addView(pad);
        LinearLayout r1=row(); r1.setPadding(0,dp(12),0,0);
        addCell(r1,"GERİ","KEY_RETURN"); addCell(r1,"EV","KEY_HOME"); addCell(r1,"MENYU","KEY_MENU"); root.addView(r1);
        LinearLayout r2=row(); addCell(r2,"SƏS −","KEY_VOLDOWN"); addCell(r2,"SUS","KEY_MUTE"); addCell(r2,"SƏS +","KEY_VOLUP"); root.addView(r2);
        LinearLayout r3=row(); addCell(r3,"KANAL −","KEY_CHDOWN"); addCell(r3,"MƏNBƏ","KEY_SOURCE"); addCell(r3,"KANAL +","KEY_CHUP"); root.addView(r3);
        LinearLayout r4=row(); addCell(r4,"PLAY / PAUSE","KEY_PLAY"); addCell(r4,"DAYAN","KEY_STOP"); root.addView(r4);
        TextView tip=text("İlk qoşulmada televizor ekranında icazə pəncərəsi görünə bilər. Telefon və TV eyni Wi-Fi şəbəkəsində olmalıdır.",11,MUTED,false); tip.setPadding(dp(3),dp(18),dp(3),0); root.addView(tip);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
    }
    private Button button(String label,boolean primary){ Button b=new Button(this); b.setText(label); b.setTextColor(WHITE); b.setTextSize(12); b.setAllCaps(false); b.setTypeface(null,Typeface.BOLD); b.setBackground(shape(primary?PURPLE:BTN,14)); b.setPadding(dp(8),dp(8),dp(8),dp(8)); return b; }
    private void addKeyRow(LinearLayout parent,String unused,String[] keys,String[] labels){
        LinearLayout r=row(); r.setPadding(0,dp(3),0,dp(3));
        for(int i=0;i<labels.length;i++){ final String k=keys[i]; Button b=button(labels[i],k.equals("KEY_ENTER")); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1); p.setMargins(dp(4),0,dp(4),0); r.addView(b,p); b.setOnClickListener(v->sendKey(k)); }
        if(labels.length==1){ View spacer=new View(this); r.addView(spacer,new LinearLayout.LayoutParams(0,dp(54),2)); }
        parent.addView(r);
    }
    private void addCell(LinearLayout r,String label,String key){ Button b=button(label,false); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(52),1); p.setMargins(dp(3),dp(3),dp(3),dp(3)); r.addView(b,p); b.setOnClickListener(v->sendKey(key)); }
    private void setStatus(String s,int color){ runOnUiThread(()->status.setText("●  "+s)); runOnUiThread(()->status.setTextColor(color)); }
    private void connect(){
        String host=ip.getText().toString().trim();
        if(host.isEmpty()){setStatus("IP ünvanını yaz",0xFFFFC857);return;}
        try{
            String name=android.util.Base64.encodeToString("Tizen Remote AZ".getBytes(StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
            String url="wss://"+host+":8002/api/v2/channels/samsung.remote.control?name="+URLEncoder.encode(name,"UTF-8");
            setStatus("Televizora qoşulur...",0xFFFFC857);
            if(ws!=null)ws.close(1000,"yenidən qoşulma");
            ws=client.newWebSocket(new Request.Builder().url(url).build(),new WebSocketListener(){
                @Override public void onOpen(WebSocket w,Response r){connected=true;setStatus("Qoşulma açıldı — TV-də icazə ver",0xFF64D99A);}
                @Override public void onMessage(WebSocket w,String s){ }
                @Override public void onFailure(WebSocket w,Throwable e,Response r){connected=false;setStatus("Xəta: "+e.getMessage(),0xFFFF7777);}
                @Override public void onClosed(WebSocket w,int c,String reason){connected=false;setStatus("Bağlantı bağlandı",0xFFFFC857);}
            });
        }catch(Exception e){setStatus("Qoşulma xətası: "+e.getMessage(),0xFFFF7777);}
    }
    private void sendKey(String key){
        if(ws==null||!connected){setStatus("Əvvəlcə TV-yə qoşul",0xFFFFC857);return;}
        try{
            JSONObject p=new JSONObject();p.put("Cmd","Click");p.put("DataOfCmd",key);p.put("Option","false");p.put("TypeOfRemote","SendRemoteKey");
            JSONObject m=new JSONObject();m.put("method","ms.remote.control");m.put("params",p);ws.send(m.toString());
        }catch(Exception e){setStatus("Düymə göndərilmədi",0xFFFF7777);}
    }
    @Override protected void onDestroy(){if(ws!=null)ws.close(1000,"çıxış");if(client!=null)client.dispatcher().executorService().shutdown();super.onDestroy();}
}
